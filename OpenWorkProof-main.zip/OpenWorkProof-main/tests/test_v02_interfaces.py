from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import pytest

import openworkproof.services as services
from openworkproof.services import OpenWorkProofServices


class _Dumpable:
    def __init__(self, value: dict[str, object]) -> None:
        self.value = value

    def model_dump(self, *, mode: str) -> dict[str, object]:
        assert mode == "json"
        return dict(self.value)


def test_services_import_without_cli_or_mcp_modules() -> None:
    code = """
import json
import sys
import openworkproof.services
print(json.dumps({
    'cli': 'openworkproof.cli' in sys.modules,
    'mcp': 'openworkproof.mcp_server' in sys.modules,
}))
"""
    completed = subprocess.run(
        [sys.executable, "-c", code],
        check=True,
        capture_output=True,
        text=True,
    )
    assert json.loads(completed.stdout) == {"cli": False, "mcp": False}


def test_services_validate_profile_returns_closed_json_dict(
    signed_verification_profile,
) -> None:
    result = OpenWorkProofServices().validate_profile(
        signed_verification_profile.model_dump(mode="json")
    )
    assert type(result) is dict
    assert result == signed_verification_profile.model_dump(mode="json")


@pytest.mark.parametrize(
    ("method", "dependency", "args", "expected_call"),
    (
        (
            "commit_arm_result",
            "commit_verification_arm_result",
            (
                Path("ledger.sqlite3"),
                {
                    "schema_version":
                        "openworkproof-verification-arm-result/0.2",
                    "payload": "arm",
                },
            ),
            (Path("ledger.sqlite3"), "parsed-arm"),
        ),
        (
            "prepare_decision",
            "prepare_verification_decision",
            (Path("ledger.sqlite3"), {"payload": "request"}),
            (Path("ledger.sqlite3"), "parsed-request"),
        ),
        (
            "commit_decision",
            "commit_verification_decision",
            (
                Path("ledger.sqlite3"),
                {
                    "schema_version":
                        "openworkproof-verification-decision/0.2",
                    "payload": "decision",
                },
            ),
            (Path("ledger.sqlite3"), "parsed-decision"),
        ),
    ),
)
def test_services_parse_then_delegate_once(
    monkeypatch, method, dependency, args, expected_call
) -> None:
    parsed = {
        "commit_arm_result": "parsed-arm",
        "prepare_decision": "parsed-request",
        "commit_decision": "parsed-decision",
    }[method]
    model_name = {
        "commit_arm_result": "VerificationArmResult",
        "prepare_decision": "DecisionDraftRequest",
        "commit_decision": "VerificationDecision",
    }[method]
    model = getattr(services, model_name)
    monkeypatch.setattr(model, "model_validate", lambda payload: parsed)
    calls = []

    def delegate(*values):
        calls.append(values)
        return _Dumpable({"result": method})

    monkeypatch.setattr(services, dependency, delegate)
    if method == "prepare_decision":
        class _Cursor:
            def __init__(self, value):
                self.value = value

            def fetchone(self):
                return (self.value,)

        class _Connection:
            def execute(self, statement):
                if "verification_profiles_v02" in statement:
                    return _Cursor(1)
                return _Cursor(0)

            def close(self):
                return None

        monkeypatch.setattr(
            services.evidence,
            "connect_ledger",
            lambda ledger: _Connection(),
        )
    result = getattr(OpenWorkProofServices(), method)(*args)
    assert type(result) is dict
    assert result == {"result": method}
    assert calls == [expected_call]


def test_services_build_and_audit_delivery_delegate_without_rules(
    tmp_path, monkeypatch
) -> None:
    ledger = tmp_path / "ledger.sqlite3"
    output = tmp_path / "package"
    calls = []

    def export(ledger_value, output_value, *, privacy_view):
        calls.append(("export", ledger_value, output_value, privacy_view))
        return _Dumpable({"kind": "manifest"})

    def audit(package):
        calls.append(("audit", package))
        return _Dumpable({"kind": "verification"})

    monkeypatch.setattr(services, "export_delivery_package", export)
    monkeypatch.setattr(services, "verify_delivery_package", audit)
    facade = OpenWorkProofServices()
    assert facade.build_delivery(
        ledger, output, "customer_private"
    ) == {"kind": "manifest"}
    assert facade.audit_delivery(output) == {"kind": "verification"}
    assert calls == [
        ("export", ledger, output, "customer_private"),
        ("audit", output),
    ]


def test_services_settlement_status_delegates_without_recomputing(
    tmp_path, monkeypatch
) -> None:
    ledger = tmp_path / "ledger.sqlite3"
    calls = []

    def read(path):
        calls.append(path)
        return _Dumpable({"settlement_readiness": "READY_FOR_ACCEPTANCE"})

    monkeypatch.setattr(services, "read_settlement_snapshot", read)
    result = OpenWorkProofServices().get_settlement_readiness(ledger)
    assert result == {"settlement_readiness": "READY_FOR_ACCEPTANCE"}
    assert calls == [ledger]


def test_services_acceptance_bundle_methods_are_thin_delegates(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ledger = tmp_path / "ledger.sqlite3"
    evidence_root = tmp_path / "evidence"
    surface = tmp_path / "surface"
    output = tmp_path / "acceptance"
    calls = []

    def export(ledger_value, evidence_value, surface_value, output_value):
        calls.append(
            ("export", ledger_value, evidence_value, surface_value, output_value)
        )
        return _Dumpable({"schema_version": "openworkproof-acceptance-bundle/0.1"})

    def verify(path):
        calls.append(("verify", path))
        return _Dumpable(
            {
                "schema_version": "openworkproof-acceptance-bundle-result/0.1",
                "terminal_decision": "ACCEPTED",
            }
        )

    monkeypatch.setattr(services, "export_acceptance_bundle", export)
    monkeypatch.setattr(services, "verify_acceptance_bundle_directory", verify)
    facade = OpenWorkProofServices()
    assert facade.build_acceptance_bundle(
        ledger,
        evidence_root,
        surface,
        output,
    ) == {
        "schema_version": "openworkproof-acceptance-bundle-result/0.1",
        "terminal_decision": "ACCEPTED",
    }
    assert facade.verify_acceptance_bundle(output) == {
        "schema_version": "openworkproof-acceptance-bundle-result/0.1",
        "terminal_decision": "ACCEPTED",
    }
    assert calls == [
        ("export", ledger, evidence_root, surface, output),
        ("verify", output),
        ("verify", output),
    ]


def test_acceptance_bundle_public_api_is_lazy_and_exact() -> None:
    import openworkproof
    from openworkproof.acceptance_bundle import (
        export_acceptance_bundle,
        verify_acceptance_bundle_directory,
    )

    assert openworkproof.export_acceptance_bundle is export_acceptance_bundle
    assert (
        openworkproof.verify_acceptance_bundle_directory
        is verify_acceptance_bundle_directory
    )


def test_services_surface_facade_delegates_to_single_core(
    tmp_path, monkeypatch
) -> None:
    from openworkproof.environment_fingerprint import (
        SignedEnvironmentFingerprintV01,
    )

    delivery = tmp_path / "delivery"
    output = tmp_path / "surface"
    first = tmp_path / "first.json"
    second = tmp_path / "second.json"
    first.write_text('{"fingerprint":"first"}', encoding="utf-8")
    second.write_text('{"fingerprint":"second"}', encoding="utf-8")
    parsed = iter(("signed-first", "signed-second"))
    calls = []

    monkeypatch.setattr(
        SignedEnvironmentFingerprintV01,
        "model_validate_json",
        lambda _payload: next(parsed),
    )
    monkeypatch.setattr(
        services,
        "build_surface_bundle",
        lambda source, fingerprints, target: calls.append(
            ("build", source, fingerprints, target)
        ),
    )

    class _Report(_Dumpable):
        decision_status = "VERIFIED"
        reason_codes = ()
        bundle_digest = "a" * 64

    class _SurfaceResult:
        report = _Report({"decision_status": "VERIFIED"})
        manifest_digest = "c" * 64

    monkeypatch.setattr(
        services,
        "verify_surface_bundle",
        lambda target: _SurfaceResult(),
    )
    facade = OpenWorkProofServices()
    result = facade.build_surface(delivery, (first, second), output)
    assert result["decision_status"] == "VERIFIED"
    assert calls == [
        ("build", delivery, ("signed-first", "signed-second"), output)
    ]


def test_v02_mcp_surface_tools_are_read_only_and_delegate_once(monkeypatch) -> None:
    import inspect

    from openworkproof import mcp_transport

    calls = []

    class FakeServices:
        def verify_surface(self, path):
            calls.append(path)
            return {
                "decision_status": "UNKNOWN",
                "reason_codes": ["ENVIRONMENT_INCOMPLETE"],
                "bundle_digest": "b" * 64,
                "report": {"decision_status": "UNKNOWN"},
            }

    monkeypatch.setattr(mcp_transport, "OpenWorkProofServices", FakeServices)
    verified = mcp_transport.owp_verify_surface_bundle("surface")
    rendered = mcp_transport.owp_render_surface_report("surface")
    assert verified["ok"] is True
    assert verified["decision_status"] == "UNKNOWN"
    assert rendered == {
        "schema_version": "openworkproof/mcp/0.2",
        "ok": True,
        "report": {"decision_status": "UNKNOWN"},
        "boundary": "not payment or acceptance",
    }
    assert calls == [Path("surface"), Path("surface")]
    for function in (
        mcp_transport.owp_verify_surface_bundle,
        mcp_transport.owp_render_surface_report,
    ):
        assert "private_key" not in inspect.signature(function).parameters


def test_v02_mcp_tools_are_registered() -> None:
    from openworkproof import mcp_transport

    names = set(mcp_transport.mcp._tool_manager._tools)
    assert {
        "owp_validate_profile",
        "owp_run_verification",
        "owp_get_decision",
        "owp_build_delivery_package",
        "owp_get_settlement_readiness",
        "owp_verify_surface_bundle",
        "owp_render_surface_report",
    } <= names


def test_v02_mcp_validate_profile_matches_service(monkeypatch) -> None:
    from openworkproof import mcp_transport

    calls = []

    class FakeServices:
        def validate_profile(self, payload):
            calls.append(payload)
            return {"profile_id": "validated"}

    monkeypatch.setattr(mcp_transport, "OpenWorkProofServices", FakeServices)
    result = mcp_transport.owp_validate_profile('{"profile_id":"candidate"}')
    assert result == {
        "schema_version": "openworkproof/mcp/0.2",
        "ok": True,
        "profile_id": "validated",
    }
    assert calls == [{"profile_id": "candidate"}]


@pytest.mark.parametrize(
    ("operation", "method"),
    (("commit_arm", "commit_arm_result"), ("commit_decision", "commit_decision")),
)
def test_v02_mcp_verification_commit_calls_service_once(
    monkeypatch, operation, method
) -> None:
    from openworkproof import mcp_transport

    calls = []

    class FakeServices:
        def commit_arm_result(self, ledger, payload):
            calls.append(("commit_arm_result", ledger, payload))
            return {"committed": "arm"}

        def commit_decision(self, ledger, payload):
            calls.append(("commit_decision", ledger, payload))
            return {"committed": "decision"}

    monkeypatch.setattr(mcp_transport, "OpenWorkProofServices", FakeServices)
    result = mcp_transport.owp_run_verification(
        "ledger.sqlite3", '{"id":"candidate"}', operation
    )
    assert result["ok"] is True
    assert calls == [(method, Path("ledger.sqlite3"), {"id": "candidate"})]


def test_v02_mcp_commit_ack_loss_returns_committed_truth(monkeypatch) -> None:
    from openworkproof import mcp_transport
    from openworkproof.verification import VerificationCommittedError

    calls = 0

    class FakeServices:
        def commit_decision(self, ledger, payload):
            nonlocal calls
            calls += 1
            raise VerificationCommittedError(
                "ack lost",
                _Dumpable({"decision_id": "committed"}),
            )

    monkeypatch.setattr(mcp_transport, "OpenWorkProofServices", FakeServices)
    result = mcp_transport.owp_run_verification(
        "ledger.sqlite3", '{"id":"candidate"}', "commit_decision"
    )
    assert result["ok"] is True
    assert result["commit_status"] == "committed_after_ack_loss"
    assert result["decision_id"] == "committed"
    assert calls == 1


def test_v02_mcp_indeterminate_commit_blocks_retry(monkeypatch) -> None:
    from openworkproof import mcp_transport
    from openworkproof.verification import VerificationCommitIndeterminateError

    calls = 0

    class FakeServices:
        def commit_arm_result(self, ledger, payload):
            nonlocal calls
            calls += 1
            raise VerificationCommitIndeterminateError("readback unavailable")

    monkeypatch.setattr(mcp_transport, "OpenWorkProofServices", FakeServices)
    result = mcp_transport.owp_run_verification(
        "ledger.sqlite3", '{"id":"candidate"}', "commit_arm"
    )
    assert result["ok"] is False
    assert result["commit_status"] == "indeterminate"
    assert calls == 1
