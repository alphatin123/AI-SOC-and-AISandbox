from __future__ import annotations

import dataclasses
import hashlib

import pytest
import rfc8785

from openworkproof.models import (
    ActionReceiptEnvelope,
    AgentRequest,
    CompositionReport,
    EvidenceRef,
)

from conftest import SHA256_A, SHA256_B, SHA256_C, SHA256_D

from openworkproof import acceptance
from openworkproof import evidence


@pytest.fixture(autouse=True)
def _stub_candidate_execution_snapshot(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stub the filesystem candidate snapshot like test_mcp_server does."""
    from openworkproof import repo_tools  # noqa: PLC0415

    def prepare(
        request,
    ) -> repo_tools.CandidateExecutionSnapshot:
        return repo_tools.CandidateExecutionSnapshot(
            head_commit=request.expected_head_commit,
            workspace_manifest_digest=(
                request.expected_workspace_manifest_digest
            ),
            plan=repo_tools.ExecutionSnapshotPlan(
                files=(),
                read_only=True,
                owner_uid=65532,
                owner_gid=65532,
                atime_unix_seconds=0,
                mtime_unix_seconds=0,
                clear_extended_attributes=True,
                clear_posix_acls=True,
                clear_file_capabilities=True,
            ),
        )

    monkeypatch.setattr(
        repo_tools,
        "prepare_candidate_execution_snapshot",
        prepare,
    )


def _node(receipt: ActionReceiptEnvelope) -> dict:
    return {
        "receipt_id": receipt.receipt_id,
        "receipt_digest": receipt.digest,
        "parent_receipt_ids": list(receipt.parent_receipt_ids),
    }


def test_causal_graph_root_is_sequence_ordered() -> None:
    receipts = tuple(
        ActionReceiptEnvelope.model_construct(
            receipt_id=f"{index:064x}",
            digest=SHA256_A,
            parent_receipt_ids=(f"{index - 1:064x}",) if index else (),
            sequence=index,
        )
        for index in range(1, 4)
    )
    expected = hashlib.sha256(
        rfc8785.dumps(
            {
                "domain": "openworkproof/causal-graph-root/0.1",
                "nodes": [
                    _node(receipt)
                    for receipt in sorted(receipts, key=lambda item: item.sequence)
                ],
            }
        )
    ).hexdigest()
    assert acceptance.causal_graph_root(receipts) == expected


def test_causal_graph_root_rejects_duplicate_or_unordered_prefix() -> None:
    receipts = tuple(
        ActionReceiptEnvelope.model_construct(
            receipt_id=f"{index:064x}",
            digest=SHA256_A,
            parent_receipt_ids=(),
            sequence=index,
        )
        for index in range(1, 3)
    )
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.causal_graph_root(receipts + receipts[:1])
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.causal_graph_root(tuple(reversed(receipts)))


def _evidence_ref(path: str, digest: str) -> EvidenceRef:
    return EvidenceRef.model_construct(
        path=path,
        sha256=digest,
        media_type="application/json",
        size_bytes=10,
    )


def _no_shared_assessment() -> dict:
    """A satisfied, disclose-only assessment with zero shared factors."""
    return {
        "policy": "disclose_only",
        "developer_reference": {
            "receipt_digest": SHA256_A,
            "factors": {
                "model_id": "dev-model",
                "model_version": "1",
                "prompt_template_digest": SHA256_A,
                "context_source_digest": SHA256_C,
                "toolchain_id": None,
                "execution_context_id": None,
                "container_instance_id_digest": None,
                "controller_id": f"ed25519:{SHA256_A}",
                "fixed_test_source_digest": None,
            },
        },
        "verifier_reference": {
            "receipt_digest": SHA256_B,
            "factors": {
                "model_id": "ver-model",
                "model_version": "1",
                "prompt_template_digest": SHA256_B,
                "context_source_digest": SHA256_D,
                "toolchain_id": None,
                "execution_context_id": None,
                "container_instance_id_digest": None,
                "controller_id": f"ed25519:{SHA256_B}",
                "fixed_test_source_digest": None,
            },
        },
        "shared_factors": [],
        "satisfied": True,
    }


def test_evidence_snapshot_digest_is_path_byte_sorted() -> None:
    refs = (
        _evidence_ref("evidence/patch-input/01.diff", SHA256_C),
        _evidence_ref("evidence/verifier-result/01.json", SHA256_B),
        _evidence_ref("evidence/verifier-result/02.json", SHA256_A),
    )
    expected = hashlib.sha256(
        rfc8785.dumps(
            {
                "domain": "openworkproof/evidence-snapshot/0.1",
                "refs": [
                    ref.model_dump(mode="json")
                    for ref in sorted(refs, key=lambda item: item.path.encode("utf-8"))
                ],
            }
        )
    ).hexdigest()
    assert acceptance.evidence_snapshot_digest(refs) == expected


def test_evidence_snapshot_digest_rejects_duplicate_paths() -> None:
    refs = (
        _evidence_ref("evidence/x/01.json", SHA256_A),
        _evidence_ref("evidence/x/01.json", SHA256_B),
    )
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.evidence_snapshot_digest(refs)


def test_composition_report_digest_is_exact_jcs_bytes() -> None:
    report = CompositionReport.model_validate(
        {
            "schema_version": "openworkproof-composition-report/0.1",
            "work_order_digest": SHA256_A,
            "initiator_receipt_id": SHA256_B,
            "initiator_receipt_digest": SHA256_C,
            "final_artifact": {
                "active_patch_receipt_digest": SHA256_A,
                "candidate_commit": "1" * 40,
                "workspace_manifest_digest": SHA256_B,
            },
            "artifact_digests": [],
            "evidence_snapshot_digest": SHA256_C,
            "receipt_digests": [SHA256_A],
            "causal_graph_root": SHA256_B,
            "causal_complete": True,
            "evidence_coverage": {"authority": True, "scope": True, "execution": True, "result": True, "independent_result": True},
            "independence_assessment": _no_shared_assessment(),
            "test_evidence_refs": [],
            "unresolved_failures": [],
            "warnings": [],
            "global_postconditions": [],
            "global_postconditions_satisfied": True,
            "verifier_conclusion": "proof_ready",
            "composed_at": "2026-01-01T00:00:00Z",
        }
    )
    canonical = rfc8785.dumps(report.model_dump(mode="json"))
    expected = hashlib.sha256(canonical).hexdigest()
    assert acceptance.composition_report_digest(report) == expected


def test_composition_report_proof_ready_requires_closed_conditions() -> None:
    def base() -> dict:
        return {
            "schema_version": "openworkproof-composition-report/0.1",
            "work_order_digest": SHA256_A,
            "initiator_receipt_id": SHA256_B,
            "initiator_receipt_digest": SHA256_C,
            "final_artifact": {
                "active_patch_receipt_digest": SHA256_A,
                "candidate_commit": "1" * 40,
                "workspace_manifest_digest": SHA256_B,
            },
            "artifact_digests": [],
            "evidence_snapshot_digest": SHA256_C,
            "receipt_digests": [SHA256_A],
            "causal_graph_root": SHA256_B,
            "causal_complete": True,
            "evidence_coverage": {"authority": True, "scope": True, "execution": True, "result": True, "independent_result": True},
            "independence_assessment": _no_shared_assessment(),
            "test_evidence_refs": [],
            "unresolved_failures": [],
            "warnings": [],
            "global_postconditions": [],
            "global_postconditions_satisfied": True,
            "verifier_conclusion": "proof_ready",
            "composed_at": "2026-01-01T00:00:00Z",
        }

    valid = CompositionReport.model_validate(base())
    assert valid.verifier_conclusion == "proof_ready"

    for path, value in (
        (("causal_complete",), False),
        (("unresolved_failures",), [{"code": "CAUSAL_INCOMPLETE", "subject_ref": SHA256_A}]),
        (("independence_assessment", "satisfied"), False),
        (("global_postconditions_satisfied",), False),
    ):
        candidate = base()
        target: dict = candidate
        for part in path[:-1]:
            target = target[part]
        target[path[-1]] = value
        with pytest.raises(ValueError, match="proof-ready report is not closed"):
            CompositionReport.model_validate(candidate)

    incomplete = base()
    incomplete["verifier_conclusion"] = "evidence_incomplete"
    incomplete["unresolved_failures"] = [
        {"code": "MISSING_EVIDENCE_DIMENSION", "subject_ref": SHA256_A}
    ]
    parsed = CompositionReport.model_validate(incomplete)
    assert parsed.verifier_conclusion == "evidence_incomplete"

    bad_incomplete = base()
    bad_incomplete["verifier_conclusion"] = "evidence_incomplete"
    with pytest.raises(ValueError, match="closed diagnostics"):
        CompositionReport.model_validate(bad_incomplete)


def test_composition_report_recomputes_shared_factor_warnings() -> None:
    # Make the developer share the model factor with the verifier so the
    # assessment recomputes ("model",) as the shared-factor registry.
    assessment = _no_shared_assessment()
    assessment["developer_reference"]["factors"]["model_id"] = "ver-model"
    assessment["developer_reference"]["factors"]["model_version"] = "1"
    assessment["shared_factors"] = ["model"]
    expected_warning = {
        "code": "SHARED_MODEL",
        "subject_ref": hashlib.sha256(
            rfc8785.dumps(
                {
                    "domain": "openworkproof/shared-factor-ref/v0.1",
                    "factor": "model",
                    "value": {"model_id": "ver-model", "model_version": "1"},
                }
            )
        ).hexdigest(),
    }
    candidate = {
        "schema_version": "openworkproof-composition-report/0.1",
        "work_order_digest": SHA256_A,
        "initiator_receipt_id": SHA256_B,
        "initiator_receipt_digest": SHA256_C,
        "final_artifact": {
            "active_patch_receipt_digest": SHA256_A,
            "candidate_commit": "1" * 40,
            "workspace_manifest_digest": SHA256_B,
        },
        "artifact_digests": [],
        "evidence_snapshot_digest": SHA256_C,
        "receipt_digests": [SHA256_A],
        "causal_graph_root": SHA256_B,
        "causal_complete": True,
        "evidence_coverage": {
            "authority": True,
            "scope": True,
            "execution": True,
            "result": True,
            "independent_result": True,
        },
        "independence_assessment": assessment,
        "test_evidence_refs": [],
        "unresolved_failures": [],
        "warnings": [expected_warning],
        "global_postconditions": [],
        "global_postconditions_satisfied": True,
        "verifier_conclusion": "proof_ready",
        "composed_at": "2026-01-01T00:00:00Z",
    }
    report = CompositionReport.model_validate(candidate)
    assert [item.code for item in report.warnings] == ["SHARED_MODEL"]
    # A report that omits the recomputed warning must fail closed.
    with pytest.raises(ValueError, match="report warnings do not match"):
        CompositionReport.model_validate(
            {**candidate, "warnings": []}
        )


def _four_dimension_work_order(
    signed_work_order,
    ephemeral_role_keys,
):
    """Return a WorkOrder variant without the independent_result dimension."""
    from test_receipt_chain import _resigned_work_order  # noqa: PLC0415

    work_order = signed_work_order
    dimensions = [
        dimension
        for dimension in work_order.required_evidence_dimensions
        if dimension != "independent_result"
    ]
    artifacts = tuple(
        artifact
        for artifact in work_order.evidence_policy.artifacts
        if artifact.purpose != "verifier_independent_result"
    )
    policy = work_order.evidence_policy.model_copy(
        update={"artifacts": artifacts}
    )
    return _resigned_work_order(
        work_order,
        ephemeral_role_keys["Maintainer"][0],
        json_updates={
            "required_evidence_dimensions": dimensions,
            "independence_policy": "disclose_only",
            "evidence_policy": policy.model_dump(mode="json"),
        },
        model_updates={
            "required_evidence_dimensions": tuple(dimensions),
            "independence_policy": "disclose_only",
            "evidence_policy": policy,
        },
    )


def _compose_case(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    now,
    monkeypatch=None,
    work_order=None,
):
    from test_mcp_server import (  # noqa: PLC0415
        _FakeRunTestsExecutionDriver,
        _current_run_tests_context,
        _execute_run_tests_case,
        _grant_id,
        _run_tests_case,
    )
    from openworkproof.models import (  # noqa: PLC0415
        ComposeProofArguments,
        request_arguments_digest,
    )
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    selected_work_order = (
        work_order
        if work_order is not None
        else signed_work_order
    )
    case = _run_tests_case(
        tmp_path=tmp_path,
        signed_work_order=selected_work_order,
        role_keys=ephemeral_role_keys,
        sidecar_receipt_factory=sidecar_receipt_factory,
        now=now,
    )
    _execute_run_tests_case(
        case,
        tmp_path,
        ephemeral_role_keys,
        _FakeRunTestsExecutionDriver(),
    )
    context = _current_run_tests_context(case, now)
    assert context.current_state == "locally_verified"
    manager = ephemeral_role_keys["Manager"][1]
    arguments = ComposeProofArguments(
        expected_state_version=evidence._derive_protocol_transaction_version(
                action_receipts=context.ledger_prefix.receipts,
                acceptance_receipts=(),
            ),
        previous_report_digest=None,
    )
    request = AgentRequest.model_validate(
        sign_payload(
            "agent-request",
            {
                "claim_type": "agent-request",
                "work_order_digest": case["work_order"].digest,
                "grant_id": case["root"].grant_id,
                "actor_id": manager["subject_id"],
                "actor_key_id": manager["key_id"],
                "tool_name": "owp.compose_proof",
                "arguments_digest": request_arguments_digest(
                    "owp.compose_proof", arguments
                ),
                "nonce": _grant_id("acceptance:compose-request"),
                "requested_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "authentication_method": "agent_signature",
                "model_id": "model",
                "model_version": "1",
                "prompt_template_digest": "a" * 64,
                "context_source_digest": "b" * 64,
            },
            ephemeral_role_keys["Manager"][0],
        )
    )
    return case, context, request




def _schema_tables(path: str) -> set[str]:
    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(path)
    try:
        rows = connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table', 'view')"
        ).fetchall()
        return {row[0] for row in rows}
    finally:
        connection.close()


def test_ledger_schema_includes_composition_reports(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, _, _ = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    tables = _schema_tables(str(case["ledger_path"]))
    assert "composition_reports" in tables


def test_composition_report_loader_rejects_tampered_json(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415

    case, context, request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    result = acceptance.compose_proof_transaction(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        request=request,
        sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
        clock=lambda: fixed_now,
    )
    connection = sqlite3.connect(case["ledger_path"])
    try:
        row = connection.execute(
            "SELECT report_json FROM composition_reports"
        ).fetchone()
        assert row is not None
        tampered = row[0].replace(
            result.report.work_order_digest, "f" * 64
        )
        connection.execute(
            "UPDATE composition_reports SET report_json = ?",
            (tampered,),
        )
        connection.commit()
    finally:
        connection.close()
    with pytest.raises(evidence.ChildGrantIssuanceError):
        evidence._validated_composition_reports(
            evidence.connect_ledger(case["ledger_path"]),
            case["work_order"],
        )


def test_compose_proof_transaction_commits_report_atomically(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    result = acceptance.compose_proof_transaction(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        request=request,
        sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
        clock=lambda: fixed_now,
    )
    assert result.report.verifier_conclusion == "evidence_incomplete"
    assert result.initiator_receipt.tool_name == "owp.compose_proof"
    assert result.trigger_receipt.system_event_name == "proof_composed"

    from openworkproof import evidence  # noqa: PLC0415

    connection = evidence.connect_ledger(case["ledger_path"])
    try:
        work_order, receipts, _, _ = (
            evidence._replay_receipt_publication_ledger(connection)
        )
        state_row = connection.execute(
            "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
        ).fetchone()
    finally:
        connection.close()
    assert state_row == ("evidence_incomplete", 6)
    assert len(receipts) == len(context.ledger_prefix.receipts) + 2
    assert receipts[-1].receipt_id == result.trigger_receipt.receipt_id
    assert receipts[-2].receipt_id == result.initiator_receipt.receipt_id
    loaded = evidence._validated_composition_reports(
        evidence.connect_ledger(case["ledger_path"]),
        work_order,
    )
    assert len(loaded) == 1
    assert loaded[0].model_dump(mode="json") == result.report.model_dump(mode="json")


def test_compose_pre_commit_failure_leaves_no_protocol_write(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415

    case, context, request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    from openworkproof import evidence  # noqa: PLC0415

    real_insert = acceptance._insert_compose_rows

    def explode_insert(*args, **kwargs):
        raise acceptance.AcceptanceTransactionError(
            "injected pre-commit failure"
        )

    monkeypatch.setattr(acceptance, "_insert_compose_rows", explode_insert)
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.compose_proof_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            clock=lambda: fixed_now,
        )
    monkeypatch.undo()

    connection = sqlite3.connect(case["ledger_path"])
    try:
        receipts = connection.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]
        reports = connection.execute(
            "SELECT COUNT(*) FROM composition_reports"
        ).fetchone()[0]
        state = connection.execute(
            "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
        ).fetchone()
    finally:
        connection.close()
    assert receipts == len(context.ledger_prefix.receipts)
    assert reports == 0
    assert state == ("locally_verified", 5)


def test_compose_requires_manager_and_current_context(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    # A stale context (clock before the signed snapshot) must fail closed.
    import dataclasses  # noqa: PLC0415
    from datetime import datetime, timezone  # noqa: PLC0415

    stale = dataclasses.replace(
        context,
        transaction_time=datetime(2026, 1, 1, 0, 0, 1, tzinfo=timezone.utc),
    )
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.compose_proof_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=stale,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            clock=lambda: fixed_now,
        )


def _request_case(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
):
    """Build a proof_ready ledger via the four-dimension WorkOrder variant."""
    from openworkproof.models import request_arguments_digest  # noqa: PLC0415
    from openworkproof.signing import sign_payload  # noqa: PLC0415
    from test_mcp_server import _grant_id  # noqa: PLC0415

    work_order = _four_dimension_work_order(
        signed_work_order, ephemeral_role_keys
    )
    case, context, compose_request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
        work_order=work_order,
    )
    composed = acceptance.compose_proof_transaction(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        request=compose_request,
        sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
        clock=lambda: fixed_now,
    )
    assert composed.report.verifier_conclusion == "proof_ready"
    from test_mcp_server import _current_run_tests_context  # noqa: PLC0415

    proof_ready_context = _current_run_tests_context(case, fixed_now)
    assert proof_ready_context.current_state == "proof_ready"
    manager = ephemeral_role_keys["Manager"][1]
    scope = {
        "work_order_digest": case["work_order"].digest,
        "operation": "submit_final_acceptance",
        "composition_report_digest": acceptance.composition_report_digest(
            composed.report
        ),
    }
    target_action_digest = hashlib.sha256(
        rfc8785.dumps(
            {
                "domain": "openworkproof/final-acceptance-action/v0.1",
                "requested_scope": scope,
            }
        )
    ).hexdigest()
    arguments = {
        "request_kind": "final_acceptance",
        "target_action_digest": target_action_digest,
        "required_role": "Acceptor",
        "requested_scope": scope,
        "expires_at": "2026-01-01T00:30:00Z",
    }
    request = AgentRequest.model_validate(
        sign_payload(
            "agent-request",
            {
                "claim_type": "agent-request",
                "work_order_digest": case["work_order"].digest,
                "grant_id": case["root"].grant_id,
                "actor_id": manager["subject_id"],
                "actor_key_id": manager["key_id"],
                "tool_name": "owp.request_acceptance",
                "arguments_digest": request_arguments_digest(
                    "owp.request_acceptance", arguments
                ),
                "nonce": _grant_id("acceptance:request"),
                "requested_at": fixed_now.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "authentication_method": "agent_signature",
                "model_id": "model",
                "model_version": "1",
                "prompt_template_digest": "a" * 64,
                "context_source_digest": "b" * 64,
            },
            ephemeral_role_keys["Manager"][0],
        )
    )
    from datetime import datetime, timezone  # noqa: PLC0415

    expires_at = datetime(2026, 1, 1, 0, 30, 0, tzinfo=timezone.utc)
    return case, proof_ready_context, request, composed, expires_at


def _commit_bound_v02_profile(
    case,
    *,
    signed_subject_claim,
    signed_verification_profile,
    ephemeral_role_keys,
) -> None:
    from openworkproof.models import SubjectClaim, VerificationProfileV02  # noqa: PLC0415
    from openworkproof.signing import sign_payload  # noqa: PLC0415
    from openworkproof.verification import commit_verification_profile  # noqa: PLC0415

    claim_raw = signed_subject_claim.model_dump(
        mode="json",
        exclude={"digest", "signature_alg", "signer_key_id", "signature"},
    )
    claim_raw.update(
        work_order_digest=case["work_order"].digest,
        source_revision=case["work_order"].source_commit,
        customer_acceptor_key_id=case["work_order"].acceptor_key_ids[0],
    )
    bound_claim = SubjectClaim.model_validate(
        sign_payload(
            "subject-claim",
            claim_raw,
            ephemeral_role_keys["Manager"][0],
        )
    )
    profile_raw = signed_verification_profile.model_dump(
        mode="json",
        exclude={"digest", "signature_alg", "signer_key_id", "signature"},
    )
    profile_raw.update(
        work_order_digest=case["work_order"].digest,
        subject_claim_digest=bound_claim.digest,
    )
    bound_profile = VerificationProfileV02.model_validate(
        sign_payload(
            "verification-profile",
            profile_raw,
            ephemeral_role_keys["Manager"][0],
        )
    )
    commit_verification_profile(
        case["ledger_path"],
        bound_claim,
        bound_profile,
    )


def test_request_acceptance_commits_awaiting_human(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    request_receipt = acceptance.request_acceptance_transaction(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        request=request,
        sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
        expires_at=expires_at,
        clock=lambda: fixed_now,
    )
    assert request_receipt.request_kind == "final_acceptance"
    assert request_receipt.required_role == "Acceptor"

    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(case["ledger_path"])
    try:
        state = connection.execute(
            "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
        ).fetchone()
        count = connection.execute(
            "SELECT COUNT(*) FROM grant_events"
        ).fetchone()[0]
    finally:
        connection.close()
    assert state == ("awaiting_human", 7)
    assert count >= 1


def test_request_acceptance_requires_proof_ready(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    from datetime import datetime, timezone  # noqa: PLC0415

    # Rewind the context to before composition (locally_verified) and
    # rewind the ledger state to match.
    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(case["ledger_path"])
    try:
        connection.execute(
            "UPDATE work_order_state SET current_state = ?, version = version - 1 "
            "WHERE singleton = 1",
            ("locally_verified",),
        )
        connection.commit()
    finally:
        connection.close()
    stale_context = dataclasses.replace(
        context,
        current_state="locally_verified",
        transaction_time=datetime(2026, 1, 1, 0, 0, 4, tzinfo=timezone.utc),
    )
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.request_acceptance_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=stale_context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            expires_at=expires_at,
            clock=lambda: fixed_now,
        )


def test_request_acceptance_requires_current_verified_v02_decision(
    tmp_path,
    signed_work_order,
    signed_subject_claim,
    signed_verification_profile,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, _, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    _commit_bound_v02_profile(
        case,
        signed_subject_claim=signed_subject_claim,
        signed_verification_profile=signed_verification_profile,
        ephemeral_role_keys=ephemeral_role_keys,
    )
    connection = evidence.connect_ledger(case["ledger_path"])
    try:
        before = (
            connection.execute("SELECT COUNT(*) FROM receipts").fetchone(),
            connection.execute(
                "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
            ).fetchone(),
        )
    finally:
        connection.close()
    with pytest.raises(
        acceptance.AcceptanceTransactionError,
        match="current VERIFIED",
    ):
        acceptance.request_acceptance_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            expires_at=expires_at,
            clock=lambda: fixed_now,
        )
    connection = evidence.connect_ledger(case["ledger_path"])
    try:
        after = (
            connection.execute("SELECT COUNT(*) FROM receipts").fetchone(),
            connection.execute(
                "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
            ).fetchone(),
        )
    finally:
        connection.close()
    assert after == before


def _awaiting_case(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
):
    """Build an awaiting_human ledger via request_acceptance_transaction."""
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    request_receipt = acceptance.request_acceptance_transaction(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        request=request,
        sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
        expires_at=expires_at,
        clock=lambda: fixed_now,
    )
    from test_mcp_server import _current_run_tests_context  # noqa: PLC0415

    awaiting_context = _current_run_tests_context(case, fixed_now)
    assert awaiting_context.current_state == "awaiting_human"
    return case, awaiting_context, composed, request_receipt


def test_prepare_acceptance_returns_deterministic_keyless_draft(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    repeat = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    assert draft.signing_domain == "acceptance-receipt"
    assert draft.canonical_payload == repeat.canonical_payload
    assert draft.acceptance_id == repeat.acceptance_id
    # The draft must not contain any credential material.
    import inspect  # noqa: PLC0415

    signature = inspect.signature(acceptance.prepare_acceptance)
    assert "private_key" not in signature.parameters
    assert b"-----BEGIN" not in draft.canonical_payload


def test_prepare_acceptance_rejects_wrong_state(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    # Still proof_ready, not awaiting_human.
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.prepare_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            clock=lambda: fixed_now,
        )


def _sign_draft(draft, ephemeral_role_keys, role="Acceptor"):
    from openworkproof.models import AcceptanceReceipt  # noqa: PLC0415
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    return AcceptanceReceipt.model_validate(
        sign_payload(
            draft.signing_domain,
            dict(draft.payload),
            ephemeral_role_keys[role][0],
        )
    )


def test_commit_acceptance_reaches_accepted(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    committed = acceptance.commit_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        acceptance=signed,
        public_keys=None,
        clock=lambda: fixed_now,
    )
    assert committed == signed

    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(case["ledger_path"])
    try:
        state = connection.execute(
            "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
        ).fetchone()
        acceptances = connection.execute(
            "SELECT COUNT(*) FROM acceptance_receipts"
        ).fetchone()[0]
    finally:
        connection.close()
    assert state == ("accepted", 8)
    assert acceptances == 1


def test_commit_acceptance_requires_current_verified_v02_decision(
    tmp_path,
    signed_work_order,
    signed_subject_claim,
    signed_verification_profile,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, _, _ = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    _commit_bound_v02_profile(
        case,
        signed_subject_claim=signed_subject_claim,
        signed_verification_profile=signed_verification_profile,
        ephemeral_role_keys=ephemeral_role_keys,
    )
    with pytest.raises(
        acceptance.AcceptanceTransactionError,
        match="current VERIFIED",
    ):
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    connection = evidence.connect_ledger(case["ledger_path"])
    try:
        assert connection.execute(
            "SELECT COUNT(*) FROM acceptance_receipts"
        ).fetchone() == (0,)
    finally:
        connection.close()


def test_commit_acceptance_rejects_wrong_signer(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    for role in ("Maintainer", "Manager", "Developer", "Verifier", "Sidecar"):
        signed = _sign_draft(draft, ephemeral_role_keys, role=role)
        with pytest.raises(acceptance.AcceptanceTransactionError):
            acceptance.commit_acceptance(
                case["ledger_path"],
                evidence_root=case["evidence_root"],
                context=context,
                acceptance=signed,
                public_keys=None,
                clock=lambda: fixed_now,
            )


def test_commit_acceptance_rejects_stale_signature(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    from datetime import datetime, timezone  # noqa: PLC0415

    later = datetime(2026, 1, 1, 0, 5, 5, tzinfo=timezone.utc)
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: later,
        )


def test_commit_acceptance_rejects_duplicate(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    acceptance.commit_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        acceptance=signed,
        public_keys=None,
        clock=lambda: fixed_now,
    )
    # A second commit against a stale awaiting_human context must fail
    # closed: either the transaction rejects it or the stale-context
    # revalidation refuses to proceed.
    with pytest.raises((acceptance.AcceptanceTransactionError, RuntimeError)):
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )


def _acceptance_request_variant(
    case,
    context,
    request,
    ephemeral_role_keys,
    fixed_now,
    *,
    signer_role="Manager",
    binding_role=None,
    nonce=None,
    requested_at=None,
    grant_id=None,
):
    """Rebuild the acceptance AgentRequest with one altered attribute.

    ``signer_role`` is the key that signs; ``binding_role`` is the actor
    identity the request declares (defaults to the signer role).
    """
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    declared_role = binding_role or signer_role
    binding = ephemeral_role_keys[declared_role][1]
    raw = {
        "claim_type": "agent-request",
        "work_order_digest": case["work_order"].digest,
        "grant_id": grant_id or case["root"].grant_id,
        "actor_id": binding["subject_id"],
        "actor_key_id": binding["key_id"],
        "tool_name": "owp.request_acceptance",
        "arguments_digest": request.arguments_digest,
        "nonce": nonce or request.nonce,
        "requested_at": (
            requested_at or fixed_now
        ).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "authentication_method": "agent_signature",
        "model_id": "model",
        "model_version": "1",
        "prompt_template_digest": "a" * 64,
        "context_source_digest": "b" * 64,
    }
    return AgentRequest.model_validate(
        sign_payload("agent-request", raw, ephemeral_role_keys[signer_role][0])
    )


def test_request_acceptance_rejects_wrong_role_signer(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    for role in ("Maintainer", "Developer", "Verifier", "Sidecar"):
        variant = _acceptance_request_variant(
            case, context, request, ephemeral_role_keys, fixed_now,
            signer_role=role,
        )
        with pytest.raises(
            acceptance.AcceptanceTransactionError, match="binding|Manager"
        ):
            acceptance.request_acceptance_transaction(
                case["ledger_path"],
                evidence_root=case["evidence_root"],
                context=context,
                request=variant,
                sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
                expires_at=expires_at,
                clock=lambda: fixed_now,
            )


def test_request_acceptance_rejects_invalid_signature(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    binding = ephemeral_role_keys["Manager"][1]
    raw = {
        "claim_type": "agent-request",
        "work_order_digest": case["work_order"].digest,
        "grant_id": case["root"].grant_id,
        "actor_id": binding["subject_id"],
        "actor_key_id": binding["key_id"],
        "tool_name": "owp.request_acceptance",
        "arguments_digest": request.arguments_digest,
        "nonce": "1" * 64,
        "requested_at": fixed_now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "authentication_method": "agent_signature",
        "model_id": "model",
        "model_version": "1",
        "prompt_template_digest": "a" * 64,
        "context_source_digest": "b" * 64,
    }
    signed = sign_payload("agent-request", raw, ephemeral_role_keys["Manager"][0])
    import base64  # noqa: PLC0415

    forged = base64.urlsafe_b64encode(b"\x01" * 64).decode().rstrip("=")
    signed["signature"] = forged
    variant = AgentRequest.model_validate(signed)
    with pytest.raises(
        acceptance.AcceptanceTransactionError, match="signature"
    ):
        acceptance._authorize_acceptance_request(context, variant)


def test_acceptance_request_authorization_rejects_stale_and_reused_nonce(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    from datetime import datetime, timezone  # noqa: PLC0415

    stale = _acceptance_request_variant(
        case, context, request, ephemeral_role_keys, fixed_now,
        requested_at=datetime(2025, 12, 31, 23, 0, 0, tzinfo=timezone.utc),
    )
    with pytest.raises(
        acceptance.AcceptanceTransactionError, match="freshness"
    ):
        acceptance._authorize_acceptance_request(context, stale)
    # nonce reuse is enforced against the signed prefix: a receipt already
    # carrying the request nonce must fail the authorization gate.
    from openworkproof.policy import AuthorizationLedgerPrefix  # noqa: PLC0415

    reused_last = context.ledger_prefix.receipts[-1].model_copy(
        update={"nonce": request.nonce}
    )
    reused_prefix = AuthorizationLedgerPrefix(
        effective_grants=context.ledger_prefix.effective_grants,
        grant_attempts=context.ledger_prefix.grant_attempts,
        receipts=context.ledger_prefix.receipts[:-1] + (reused_last,),
    )
    reused_context = dataclasses.replace(
        context,
        ledger_prefix=reused_prefix,
    )
    with pytest.raises(
        acceptance.AcceptanceTransactionError, match="nonce"
    ):
        acceptance._authorize_acceptance_request(reused_context, request)


def test_request_acceptance_rejects_revoked_and_exhausted_grant(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    from openworkproof.policy import AuthorizationReplayState  # noqa: PLC0415

    revoked = dataclasses.replace(
        context,
        replay_state=AuthorizationReplayState(
            active_patch_receipt_id=context.replay_state.active_patch_receipt_id,
            balances=context.replay_state.balances,
            revoked_grant_ids=(request.grant_id,),
            used_single_use_grant_ids=(
                context.replay_state.used_single_use_grant_ids
            ),
            approval_decision_by_request=(
                context.replay_state.approval_decision_by_request
            ),
        ),
    )
    with pytest.raises(
        acceptance.AcceptanceTransactionError, match="revoked"
    ):
        acceptance._authorize_acceptance_request(revoked, request)
    exhausted_balances = tuple(
        (grant_id, metric, 0)
        for grant_id, metric, _ in context.replay_state.balances
    )
    exhausted = dataclasses.replace(
        context,
        replay_state=AuthorizationReplayState(
            active_patch_receipt_id=context.replay_state.active_patch_receipt_id,
            balances=exhausted_balances,
            revoked_grant_ids=context.replay_state.revoked_grant_ids,
            used_single_use_grant_ids=(
                context.replay_state.used_single_use_grant_ids
            ),
            approval_decision_by_request=(
                context.replay_state.approval_decision_by_request
            ),
        ),
    )
    with pytest.raises(
        acceptance.AcceptanceTransactionError, match="quota"
    ):
        acceptance._authorize_acceptance_request(exhausted, request)


class _AckLossConnection:
    """Wraps a ledger connection and drops COMMIT acknowledgements."""

    def __init__(self, real):
        self._real = real

    def __getattr__(self, name):
        return getattr(self._real, name)

    def execute(self, *args, **kwargs):
        statement = args[0] if args else ""
        if isinstance(statement, str) and statement.strip().upper() == "COMMIT":
            # The commit physically succeeds; only the acknowledgement is lost.
            result = self._real.execute(*args, **kwargs)
            raise sqlite3.OperationalError("injected acknowledgement loss")
        return self._real.execute(*args, **kwargs)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return self._real.__exit__(*args)


def test_compose_commit_ack_loss_recovers_exact_truth(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415

    case, context, request = _compose_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    real_connect = evidence.connect_ledger
    monkeypatch.setattr(
        evidence,
        "connect_ledger",
        lambda p: _AckLossConnection(real_connect(p)),
    )
    with pytest.raises(
        acceptance.AcceptanceCommittedError,
        match="acknowledgement was lost",
    ) as captured:
        acceptance.compose_proof_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            clock=lambda: fixed_now,
        )
    monkeypatch.undo()
    committed = captured.value.committed
    assert committed.report.verifier_conclusion == "evidence_incomplete"
    # The exact write is provably present after recovery.
    connection = sqlite3.connect(case["ledger_path"])
    try:
        reports = connection.execute(
            "SELECT COUNT(*) FROM composition_reports"
        ).fetchone()[0]
        state = connection.execute(
            "SELECT current_state FROM work_order_state WHERE singleton = 1"
        ).fetchone()[0]
    finally:
        connection.close()
    assert reports == 1
    assert state == "evidence_incomplete"


def test_request_commit_ack_loss_recovers_exact_truth(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    real_connect = evidence.connect_ledger
    monkeypatch.setattr(
        evidence,
        "connect_ledger",
        lambda p: _AckLossConnection(real_connect(p)),
    )
    with pytest.raises(
        acceptance.AcceptanceCommittedError,
        match="acknowledgement was lost",
    ) as captured:
        acceptance.request_acceptance_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            expires_at=expires_at,
            clock=lambda: fixed_now,
        )
    monkeypatch.undo()
    committed = captured.value.committed
    assert committed.request_kind == "final_acceptance"


def test_commit_ack_loss_recovers_exact_truth(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    real_connect = evidence.connect_ledger
    monkeypatch.setattr(
        evidence,
        "connect_ledger",
        lambda p: _AckLossConnection(real_connect(p)),
    )
    with pytest.raises(
        acceptance.AcceptanceCommittedError,
        match="acknowledgement was lost",
    ) as captured:
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    monkeypatch.undo()
    committed = captured.value.committed
    assert committed == signed


def test_commit_readback_failure_is_indeterminate_not_silent(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    monkeypatch.setattr(
        acceptance,
        "_readback_request_committed",
        lambda *a, **k: False,
    )
    with pytest.raises(
        acceptance.AcceptanceCommitIndeterminateError,
        match="readback could not confirm",
    ):
        acceptance.request_acceptance_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            expires_at=expires_at,
            clock=lambda: fixed_now,
        )


def _request_table_snapshot(ledger_path) -> dict:
    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(ledger_path)
    try:
        return {
            "receipts": connection.execute("SELECT COUNT(*) FROM receipts").fetchone()[0],
            "parents": connection.execute("SELECT COUNT(*) FROM receipt_parents").fetchone()[0],
            "events": connection.execute("SELECT COUNT(*) FROM grant_events").fetchone()[0],
            "reports": connection.execute("SELECT COUNT(*) FROM composition_reports").fetchone()[0],
            "acceptances": connection.execute("SELECT COUNT(*) FROM acceptance_receipts").fetchone()[0],
            "state": connection.execute(
                "SELECT current_state, version FROM work_order_state WHERE singleton = 1"
            ).fetchone(),
        }
    finally:
        connection.close()


def test_request_acceptance_rejects_expiry_violations(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from datetime import datetime, timedelta, timezone  # noqa: PLC0415

    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    past = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    too_long = datetime(2026, 1, 1, 1, 30, 0, tzinfo=timezone.utc)
    # The WorkOrder deadline is 2026-01-02, so a >1-hour expiry is rejected
    # by the one-hour window before the deadline check can fire.
    for bad_expiry, message in (
        (past, "within one hour"),
        (too_long, "within one hour"),
    ):
        before = _request_table_snapshot(case["ledger_path"])
        with pytest.raises(
            acceptance.AcceptanceTransactionError, match=message
        ):
            acceptance.request_acceptance_transaction(
                case["ledger_path"],
                evidence_root=case["evidence_root"],
                context=context,
                request=request,
                sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
                expires_at=bad_expiry,
                clock=lambda: fixed_now,
            )
        assert _request_table_snapshot(case["ledger_path"]) == before


def test_request_acceptance_rejects_evidence_drift(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, request, composed, expires_at = _request_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    # Tamper a committed evidence artifact under the evidence root; the
    # current-context gate must fail closed before any write.
    import sqlite3  # noqa: PLC0415

    connection = sqlite3.connect(case["ledger_path"])
    try:
        path = connection.execute(
            "SELECT final_path FROM evidence_publications LIMIT 1"
        ).fetchone()[0]
    finally:
        connection.close()
    from pathlib import Path  # noqa: PLC0415

    artifact = (
        case["evidence_root"] / path.removeprefix("evidence/")
    )
    original = artifact.read_bytes()
    artifact.write_bytes(original + b"\ntampered")
    before = _request_table_snapshot(case["ledger_path"])
    with pytest.raises(Exception):
        acceptance.request_acceptance_transaction(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            request=request,
            sidecar_private_key=ephemeral_role_keys["Sidecar"][0],
            expires_at=expires_at,
            clock=lambda: fixed_now,
        )
    artifact.write_bytes(original)
    assert _request_table_snapshot(case["ledger_path"]) == before


def test_acceptance_receipt_offline_verification(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    """A copied bundle verifies without reopening the live ledger."""
    import json  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415
    from openworkproof.models import (  # noqa: PLC0415
        ACTION_RECEIPT_ADAPTER,
        AcceptanceReceipt,
        CapabilityGrant,
        WorkOrder,
    )
    from openworkproof.policy import CommittedEvidence  # noqa: PLC0415
    from openworkproof.signing import (  # noqa: PLC0415
        decode_and_verify_key_binding,
    )

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    bundle = tmp_path / "offline-acceptance-bundle"
    bundle.mkdir()
    (bundle / "work-order.json").write_bytes(
        rfc8785.dumps(case["work_order"].model_dump(mode="json"))
    )
    (bundle / "composition-report.json").write_bytes(
        rfc8785.dumps(composed.report.model_dump(mode="json"))
    )
    (bundle / "acceptance-receipt.json").write_bytes(
        rfc8785.dumps(signed.model_dump(mode="json"))
    )
    (bundle / "effective-grants.json").write_bytes(
        rfc8785.dumps(
            [
                grant.model_dump(mode="json")
                for grant in context.ledger_prefix.effective_grants
            ]
        )
    )
    (bundle / "grant-attempts.json").write_bytes(
        rfc8785.dumps(
            [
                grant.model_dump(mode="json")
                for grant in context.ledger_prefix.grant_attempts
            ]
        )
    )
    receipts_dir = bundle / "receipts"
    receipts_dir.mkdir()
    for receipt in context.ledger_prefix.receipts:
        (receipts_dir / f"{receipt.sequence:03d}.json").write_bytes(
            rfc8785.dumps(receipt.model_dump(mode="json"))
        )
    evidence_dir = bundle / "evidence"
    evidence_dir.mkdir()
    evidence_index = []
    for index, item in enumerate(context.committed_evidence):
        filename = f"{index:03d}.bin"
        (evidence_dir / filename).write_bytes(item.payload)
        evidence_index.append(
            {
                "filename": filename,
                "reference": item.reference.model_dump(mode="json"),
            }
        )
    (bundle / "evidence-index.json").write_bytes(
        rfc8785.dumps(evidence_index)
    )

    loaded_work_order = WorkOrder.model_validate_json(
        (bundle / "work-order.json").read_bytes()
    )
    loaded_report = CompositionReport.model_validate_json(
        (bundle / "composition-report.json").read_bytes()
    )
    loaded_acceptance = AcceptanceReceipt.model_validate_json(
        (bundle / "acceptance-receipt.json").read_bytes()
    )
    loaded_grants = tuple(
        CapabilityGrant.model_validate(item)
        for item in json.loads((bundle / "effective-grants.json").read_bytes())
    )
    loaded_attempts = tuple(
        CapabilityGrant.model_validate(item)
        for item in json.loads((bundle / "grant-attempts.json").read_bytes())
    )
    loaded_receipts = tuple(
        ACTION_RECEIPT_ADAPTER.validate_json(path.read_bytes())
        for path in sorted(receipts_dir.iterdir())
    )
    loaded_evidence = tuple(
        CommittedEvidence(
            reference=EvidenceRef.model_validate(item["reference"]),
            payload=(evidence_dir / item["filename"]).read_bytes(),
        )
        for item in json.loads((bundle / "evidence-index.json").read_bytes())
    )
    public_keys = {
        binding.key_id: decode_and_verify_key_binding(binding)
        for binding in loaded_work_order.key_bindings
    }
    monkeypatch.setattr(
        evidence,
        "connect_ledger",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(
            AssertionError("offline verification reopened the live ledger")
        ),
    )
    verified = acceptance.verify_acceptance_bundle(
        work_order=loaded_work_order,
        report=loaded_report,
        effective_grants=loaded_grants,
        grant_attempts=loaded_attempts,
        receipts=loaded_receipts,
        committed_evidence=loaded_evidence,
        acceptance_receipt=loaded_acceptance,
        public_keys=public_keys,
    )
    assert verified == loaded_acceptance


def test_acceptance_commits_serialize_under_target_lock(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    """Concurrent identical acceptances expose one exact committed truth."""
    import threading  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    outcomes = []
    barrier = threading.Barrier(2)

    def attempt():
        barrier.wait()
        try:
            committed = acceptance.commit_acceptance(
                case["ledger_path"],
                evidence_root=case["evidence_root"],
                context=context,
                acceptance=signed,
                public_keys=None,
                clock=lambda: fixed_now,
            )
            outcomes.append(("success", committed))
        except acceptance.AcceptanceCommittedError as error:
            outcomes.append(("committed", error.committed))
        except Exception as error:  # noqa: BLE001
            outcomes.append((type(error).__name__, None))

    threads = [
        threading.Thread(target=attempt),
        threading.Thread(target=attempt),
    ]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=30)
    assert len(outcomes) == 2
    assert [kind for kind, _ in outcomes].count("success") == 1, outcomes
    assert [kind for kind, _ in outcomes].count("committed") == 1, outcomes
    assert all(result == signed for _, result in outcomes)
    state = _request_table_snapshot(case["ledger_path"])
    assert state["state"] == ("accepted", 8)
    assert state["acceptances"] == 1


def test_acceptance_suffix_rejects_valid_signature_bound_to_other_request(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415
    from openworkproof.models import AcceptanceReceipt  # noqa: PLC0415
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    acceptance.commit_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        acceptance=signed,
        public_keys=None,
        clock=lambda: fixed_now,
    )
    payload = dict(draft.payload)
    payload["acceptance_request_receipt_id"] = "e" * 64
    payload["acceptance_request_receipt_digest"] = "f" * 64
    payload["acceptance_id"] = acceptance.acceptance_id(
        work_order_digest=case["work_order"].digest,
        request_receipt_id=payload["acceptance_request_receipt_id"],
        request_receipt_digest=payload["acceptance_request_receipt_digest"],
        report_digest=payload["composition_report_digest"],
        evidence_snapshot=payload["evidence_snapshot_digest"],
    )
    alien = AcceptanceReceipt.model_validate(
        sign_payload(
            "acceptance-receipt",
            payload,
            ephemeral_role_keys["Acceptor"][0],
        )
    )
    connection = sqlite3.connect(case["ledger_path"])
    try:
        connection.execute(
            "UPDATE acceptance_receipts "
            "SET acceptance_id = ?, acceptance_json = ?",
            (
                alien.acceptance_id,
                evidence._canonical_json(alien.model_dump(mode="json")),
            ),
        )
        connection.commit()
    finally:
        connection.close()
    connection = evidence.connect_ledger(case["ledger_path"])
    try:
        with pytest.raises(evidence.ChildGrantIssuanceError):
            evidence._replay_receipt_publication_ledger(connection)
    finally:
        connection.close()


def test_acceptance_readback_rejects_same_id_with_different_canonical_receipt(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415
    from datetime import timedelta  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415
    from openworkproof.models import AcceptanceReceipt  # noqa: PLC0415
    from openworkproof.signing import sign_payload  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    acceptance.commit_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        acceptance=signed,
        public_keys=None,
        clock=lambda: fixed_now,
    )
    alternate_payload = dict(draft.payload)
    alternate_payload["accepted_at"] = (
        fixed_now + timedelta(seconds=1)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")
    alternate = AcceptanceReceipt.model_validate(
        sign_payload(
            "acceptance-receipt",
            alternate_payload,
            ephemeral_role_keys["Acceptor"][0],
        )
    )
    assert alternate.acceptance_id == signed.acceptance_id
    assert alternate != signed
    connection = sqlite3.connect(case["ledger_path"])
    try:
        connection.execute(
            "UPDATE acceptance_receipts SET acceptance_json = ?",
            (evidence._canonical_json(alternate.model_dump(mode="json")),),
        )
        connection.commit()
    finally:
        connection.close()
    assert not acceptance._readback_acceptance_committed(
        case["ledger_path"],
        work_order=case["work_order"],
        acceptance=signed,
    )


def test_acceptance_close_failure_preserves_proven_committed_truth(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    real_close = evidence._best_effort_close
    real_readback = acceptance._readback_acceptance_committed
    armed = False

    def confirm_then_arm(*args, **kwargs):
        nonlocal armed
        confirmed = real_readback(*args, **kwargs)
        if confirmed:
            armed = True
        return confirmed

    def close_then_fail(connection):
        real_close(connection)
        return RuntimeError("injected close failure") if armed else None

    monkeypatch.setattr(
        acceptance,
        "_readback_acceptance_committed",
        confirm_then_arm,
    )
    monkeypatch.setattr(evidence, "_best_effort_close", close_then_fail)
    with pytest.raises(acceptance.AcceptanceCommittedError) as captured:
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    assert captured.value.committed == signed


@pytest.mark.parametrize(
    "fault_point",
    ("before_insert", "after_insert", "after_state_update"),
)
def test_acceptance_precommit_faults_leave_exact_snapshot(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
    fault_point,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    before = _request_table_snapshot(case["ledger_path"])
    real_insert = acceptance._insert_acceptance_rows

    def inject(connection, *, work_order, acceptance, current_state, current_version):
        if fault_point == "before_insert":
            raise acceptance_module_error()
        if fault_point == "after_insert":
            connection.execute(
                "INSERT INTO acceptance_receipts "
                "(acceptance_id, work_order_digest, acceptance_json) "
                "VALUES (?, ?, ?)",
                (
                    acceptance.acceptance_id,
                    work_order.digest,
                    evidence._canonical_json(
                        acceptance.model_dump(mode="json")
                    ),
                ),
            )
            raise acceptance_module_error()
        real_insert(
            connection,
            work_order=work_order,
            acceptance=acceptance,
            current_state=current_state,
            current_version=current_version,
        )
        raise acceptance_module_error()

    def acceptance_module_error():
        return acceptance.AcceptanceTransactionError(
            f"injected {fault_point} failure"
        )

    monkeypatch.setattr(acceptance, "_insert_acceptance_rows", inject)
    with pytest.raises(acceptance.AcceptanceTransactionError):
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    assert _request_table_snapshot(case["ledger_path"]) == before


def test_acceptance_commit_failure_before_effect_rolls_back_exactly(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    import sqlite3  # noqa: PLC0415

    from openworkproof import evidence  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    before = _request_table_snapshot(case["ledger_path"])
    real_connect = evidence.connect_ledger

    class CommitFailureConnection(_AckLossConnection):
        def execute(self, *args, **kwargs):
            statement = args[0] if args else ""
            if (
                isinstance(statement, str)
                and statement.strip().upper() == "COMMIT"
            ):
                raise sqlite3.OperationalError(
                    "injected commit failure before effect"
                )
            return self._real.execute(*args, **kwargs)

    monkeypatch.setattr(
        evidence,
        "connect_ledger",
        lambda path: CommitFailureConnection(real_connect(path)),
    )
    with pytest.raises(acceptance.AcceptanceCommitIndeterminateError):
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    monkeypatch.undo()
    assert _request_table_snapshot(case["ledger_path"]) == before


def test_acceptance_lock_release_failure_preserves_proven_committed_truth(
    tmp_path,
    signed_work_order,
    ephemeral_role_keys,
    sidecar_receipt_factory,
    fixed_now,
    monkeypatch,
) -> None:
    from openworkproof import evidence  # noqa: PLC0415

    case, context, composed, request_receipt = _awaiting_case(
        tmp_path,
        signed_work_order,
        ephemeral_role_keys,
        sidecar_receipt_factory,
        fixed_now,
        monkeypatch,
    )
    draft = acceptance.prepare_acceptance(
        case["ledger_path"],
        evidence_root=case["evidence_root"],
        context=context,
        clock=lambda: fixed_now,
    )
    signed = _sign_draft(draft, ephemeral_role_keys)
    real_release = evidence._release_target_lock

    def release_then_fail(descriptor):
        released, errors = real_release(descriptor)
        return released, (*errors, RuntimeError("injected release failure"))

    monkeypatch.setattr(evidence, "_release_target_lock", release_then_fail)
    with pytest.raises(acceptance.AcceptanceCommittedError) as captured:
        acceptance.commit_acceptance(
            case["ledger_path"],
            evidence_root=case["evidence_root"],
            context=context,
            acceptance=signed,
            public_keys=None,
            clock=lambda: fixed_now,
        )
    assert captured.value.committed == signed
