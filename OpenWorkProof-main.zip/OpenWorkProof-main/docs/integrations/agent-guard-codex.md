# OWP Guard：Codex 本地预览目录保护（实验性）

状态：1.5.0 包内提供实验性 `owp-guard` 命令。实机验证环境为 macOS、Python 3.12 与 Codex CLI 0.147.0；其他宿主组合须先通过兼容检查。

## 使用目的与验收约定

用户在原 Agent 中修改一份预览副本。OWP 自动检查宿主交来的工具请求：
允许读取、增加和修改指定预览目录内的普通文件；拒绝越界文件、删除/移动、
任意执行命令及未支持的工具。用户无需创建另一套工作单。

首版有意限制命令能力，适合文本/静态页面预览编辑，不适合构建、测试、部署等
需要任意程序执行的任务。具体命令白名单随实现列明。

实现顺序和成功标准：

1. 检查器：真实工具输入得到稳定的允许/拒绝；路径穿越、符号链接、多文件补丁、
   命令拼接、未知工具、缺失策略均有负例，拒绝前没有执行副作用。
2. 项目安装：只注册本项目的同步 PreToolUse，保留其他 Hook；重复安装不叠加；
   状态分别显示已配置与本地检查记录；宿主是否调用另用真实宿主事件核验。
   卸载恢复原配置或保留安装后的其他改动。
3. 真实宿主：在单独体验目录让 Codex 读取/编辑预览、尝试越界与命令写入，
   对照文件结果和本地检查记录。测试脚本调用检查器不算真实宿主验收。

## 数据与权限

- 策略由安装者设置，存放在项目可编辑范围之外；Agent 工具输入不能授予权限。
- 首版策略格式 `openworkproof/agent-guard/0.1`，字段为 `project_root`、
  `allowed_directory`、`installation_id`。所有目录在安装时解析为绝对真实路径。
- 运行时文件为独立的标准库模块 `agent_guard.py`，安装时复制到本机状态目录，
  由固定 Python 路径以 `-I` 启动，避免从 Agent 工作目录导入代码。
- `Bash` 与 `apply_patch` 输入使用 `tool_input.command`；补丁按宿主格式解析
  所有路径。只读命令也只能访问预览目录；隐藏路径、链接和多硬链接文件拒绝。
- 不信任提示词中的批准声明，不读取 transcript，不发送遥测或增加外部模型服务。
  本地记录只含时间、决定、固定原因码、工具类别、输入摘要及策略摘要，不存原文。
  这些记录未签名，手动运行检查器也能产生，不能单独证明宿主触达或独立验收。
- 正常请求返回空 JSON，保留宿主原有权限判断；拒绝返回原厂支持的 `deny`。
  Python 失败由外层包装器转为拒绝，不能使用异步 Hook 或不受支持的 `ask`。

## 首版边界

这是宿主执行前的工具限制，不是操作系统隔离，也没有运行中终止/回滚能力。
本组件只处理宿主交来的执行前请求，不宣称已运行完整签名授权与独立验收协议。
既有 Core、Desk 和运行中的服务不因安装而改变。

必须由宿主实际启用并信任 Hook。Codex 默认在 Hook 缺失、超时、定义不受信任或
部分错误时继续；包装器只能处理它已经启动后的内部失败。状态不能据配置存在
宣称全局生效。项目可信、Hook 可信、原厂权限设置仍由宿主管理。

官方不为 `write_stdin` 的后续输入再次触发 PreToolUse，所以首版拒绝交互/PTY和
任意命令。Hosted WebSearch 等原厂列明路径未覆盖；专用体验启动应关闭在线搜索，
不能据未知工具拒绝推成所有行为受控。管理员/同一系统用户禁用 Hook、外部进程
同时替换文件、检查与执行间的竞态均不属于本机制能消除的威胁。

原厂契约：<https://learn.chatgpt.com/docs/hooks>（核查日期 2026-10-26）。
WorkBuddy 5.8.3 当前尚未核实同等桌面执行前阻断契约，不能标为已支持。

## 开发与验证

### 从当前源码使用

1.5.0 提供独立命令，可用 `uv tool install 'openworkproof==1.5.0'` 安装到隔离工具环境。
随后按[首次启用流程](agent-guard-onboarding.md)使用 `owp-guard`。以下是仓库开发环境的等价调用；安装 MCP 不会自动启用 Guard。

```sh
PYTHONPATH=src .venv/bin/python -m openworkproof.guard_cli install \
  --project /absolute/site-project --allow-dir preview --human
PYTHONPATH=src .venv/bin/python -m openworkproof.guard_cli status \
  --project /absolute/site-project --human
PYTHONPATH=src .venv/bin/python -m openworkproof.guard_cli uninstall \
  --project /absolute/site-project --human
```

项目与预览子目录应已经存在。默认控制文件位于
`~/.local/share/openworkproof/guard/<项目路径摘要>/`，不在 Agent 可编辑目录内。
`--state-dir` 可以指定本地控制目录；后续状态、升级与卸载须使用同一目录。
不带 `--human` 时返回 JSON，供自动化使用。

安装只配置项目 `.codex/hooks.json`，不会替用户设置全局项目可信或 Hook 信任。
已新增 [首次启用与受保护启动](agent-guard-onboarding.md)：通过 `enable` 审阅当前版本并
完成真实检查，再用 `run` 在原生 Codex 引擎中执行任务。该入口只传入单条 session trust。
若直接普通启动 Codex，仍需将项目设为可信，再通过 `/hooks` 审阅、信任并启用 OWP 项。
源码、范围或包装器升级会改变定义；使用 `install --upgrade` 显式更新并重新信任。
有漂移时安装拒绝覆盖；卸载在可确认唯一自有条目时仍能移除接入，保留他人配置。
卸载会保留本地安装记录与事件文件，输出其位置，不宣称已经删除所有本地数据。

只读命令限 `/bin/pwd`、不带选项的 `/bin/ls`、`/bin/cat`（可用 `-n`）。
文件路径须位于预览目录；不接受拼接、替换、通配符、交互参数或隐含执行能力。
不支持的操作会向原 Agent 返回中文理由；允许结果不会绕过宿主自己的权限检查。

### 2026-10-26 本地验收结果

- 检查器与安装生命周期测试：130 passed。
- 本地 wheel 在独立环境安装，包入口完成安装、幂等、状态和卸载；原有 Hook
  配置按原始字节恢复。
- 真实 Codex CLI 0.147.0 从项目 Hook 文件加载：正常读取与单处页面标题修改成功；
  越界创建、命令写入、隐藏假密钥读取均被拒绝。原件和官网源码未变，两个拒绝目标
  没有生成，假密钥值未出现在最终宿主事件流中。
- 实机验收显式设置了**本次调用的项目信任**并使用
  `--dangerously-bypass-hook-trust`，该开关跳过 Codex 自己的持久信任审阅。
  因此它证明所安装检查器在这次调用中的真实阻断，不证明普通启动已自动启用或已经
  通过 Codex `/hooks` 的交互式信任流程。验收没有修改用户全局配置或持久化信任。

失败的调试轮次也保留：桌面模型别名不适用于 CLI、关闭工具执行入口，以及测试命令
错误设置项目信任，均未计入成功。后者曾让负例实际执行，测试文件已恢复。
该版本 CLI 的 `-c` 左侧按点拆分，不解析 TOML 带引号的路径键；自动化中应把整个
项目表放在右值，例如单个参数
`projects={"/absolute/site-project"={trust_level="trusted"}}`。
不要因为跳过了 Hook 信任检查，就认为项目层也已受信任。

```sh
PYTHONPATH=src .venv/bin/python -m pytest -q \
  tests/test_agent_guard.py tests/test_guard_cli.py
```

验收使用合成拒绝目标与假密钥；代码审查来自同一 AI 协作团队的另一审查 Agent，
不是客户独立验收。这组历史实机记录不证明 WorkBuddy 接入、企业部署或客户独立验收；当前包发布状态见发行入口。
